create view cid3 as
select `smazon`.`tb_category`.`parent_id` AS `parent_id`
from `smazon`.`tb_category`
group by `smazon`.`tb_category`.`parent_id`;

-- comment on column cid3.parent_id not supported: 父类目id,顶级类目填0

